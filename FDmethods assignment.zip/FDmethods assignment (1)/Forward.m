function [m1] = Forward(arr, y)
for i = 1:numel (y) - 1
    m1(i) = (y(i + 1) - y(i)) / (arr(i + 1) - arr(i));
end 

m1(numel(y)) = nan;

return
