function [m2] = Backward(arr, y)
m2(1) = nan;
for i = 2:numel(y) - 1
    m2(i) = (y(i + 1) - y(i - 1)) / (arr(i + 1) - arr(i - 1));
end 
m2(numel(y)) = nan;


return