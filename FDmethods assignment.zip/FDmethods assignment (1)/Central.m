function [m3] = Central(arr, y)
m3(1) = nan;
for i = 2:numel(y)
    m3(i) = (y(i) - y(i - 1)) / (arr(i) - arr(i - 1));
end

return