clear all
close all
clc


% JACOB WICKLINE HELPED ME WITH THIS 
% ASSIGNMENT BECAUSE MY BRAIN IS SMOOTH


%code to request an array
 arr = input('Please input an array: ');

%test equation
% x = -5:0.1:5;
y = arr.^2;
dy = 2 * arr;

nexttile

[m1] = Forward(arr,y);
plot (arr, dy, 'k', arr , m1, 'b' )
title ('Plot Forward')

nexttile

[m2] = Backward(arr,y);
plot (arr, dy, 'k', arr , m2, 'g' )

title ('Plot Backward')

nexttile

[m3] = Central(arr,y);
plot (arr, dy, 'k', arr , m3, '' )

title ('Plot Central')

