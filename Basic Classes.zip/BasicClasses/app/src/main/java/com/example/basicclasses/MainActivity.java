package com.example.basicclasses;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Soldier rambo = new Soldier();
        rambo.soldierType = "Green Beret";
        rambo.health = 150;

    Soldier vassily = new Soldier();
    vassily.soldierType = "Sniper";
    vassily.health = 50;

    Soldier wellington = new Soldier();
    wellington.soldierType = "Sailor";
    wellington.health = 100;

    Log.i("Rambo's health = ","" + rambo.health);
    Log.i("Vassily's health = ","" + vassily.health);
    Log.i("Wellington's health = ","" + wellington.health);

    rambo.shootEnemy();
    vassily.shootEnemy();
    wellington.shootEnemy();

    rambo.healSoldier(rambo);
    vassily.healSoldier(vassily);
    wellington.healSoldier(wellington);

    Handler handler = new Handler();
        handler.postDelayed(() -> {
            TextView myTextView2 = (TextView) findViewById(R.id.textView2);
            float temp = vassily.health;
            String str = Double.toString(temp);
            myTextView2.setText(str);  //match myTextView2 with your object name for Vassily's health
            }, 5000);

        TextView myTextView4 = (TextView) findViewById(R.id.textView4);  //replace textView with your textView ID
        float temp3 = (rambo.health);
        String str3 = Double.toString(temp3);
        myTextView4.setText(str3);

        TextView myTextView6 = (TextView) findViewById(R.id.textView6);  //replace textView with your textView ID
        float temp2 = (vassily.health);
        String str2 = Double.toString(temp2);
        myTextView6.setText(str2);

        TextView myTextView8 = (TextView) findViewById(R.id.textView8);  //replace textView with your textView ID
        float temp4 = (wellington.health);
        String str4 = Double.toString(temp4);
        myTextView8.setText(str4);
    }
}