package com.example.basicclasses;

import android.util.Log;

public class Soldier {
    int health;
    String soldierType;

    void shootEnemy(){
        //lets print what type of soldier is shooting
        Log.i(soldierType, " is shooting");
    }

    Soldier healSoldier(Soldier soldierToBeHealed){
        soldierToBeHealed.health += 100;
        return soldierToBeHealed;
    }
}
