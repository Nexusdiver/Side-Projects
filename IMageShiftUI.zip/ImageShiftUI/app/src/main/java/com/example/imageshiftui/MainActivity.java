package com.example.imageshiftui;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button increase, decrease, squeeze, separate, hide, dim, bright, left,
            right, center, reset1, reset2, small, medium, large;
    private float ourFontsize = 14f;
    private float ourLetterSpacing = 0f;
    private int ourCount = 1;
    TextView tvText, count;
    ImageView selfie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        increase = findViewById(R.id.increase);
        decrease = findViewById(R.id.decrease);
        squeeze = findViewById(R.id.squeeze);
        separate = findViewById(R.id.separate);
        hide = findViewById(R.id.hide);
        dim = findViewById(R.id.dim);
        bright = findViewById(R.id.bright);
        tvText = findViewById(R.id.tvText);
        selfie = findViewById(R.id.selfie);
        left = findViewById(R.id.left);
        right = findViewById(R.id.right);
        center = findViewById(R.id.center);
        small = findViewById(R.id.small);
        medium = findViewById(R.id.medium);
        large = findViewById(R.id.large);
        count = findViewById(R.id.count);
        reset1 = findViewById(R.id.reset1);
        reset2 = findViewById(R.id.reset2);

        increase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ourFontsize += 4f;
                tvText.setTextSize(ourFontsize);
                tvText.setText("" + ourFontsize);
            }
        });
        decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ourFontsize -= 4f;
                tvText.setTextSize(ourFontsize);
                tvText.setText("" + ourFontsize);
            }
        });
        squeeze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ourLetterSpacing -= 0.1f;
                if (ourLetterSpacing < 0) ourLetterSpacing = 0;
                tvText.setLetterSpacing(ourLetterSpacing);
            }
        });
        separate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ourLetterSpacing += 0.1f;
                if (ourLetterSpacing < 0) ourLetterSpacing = 0;
                tvText.setLetterSpacing(ourLetterSpacing);
            }
        });
       reset1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               ourLetterSpacing = 0;
               ourFontsize = 14f;
               tvText.setGravity(Gravity.LEFT);
           }
       });
        reset2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selfie.getLayoutParams().height = 300;
                selfie.setAlpha(.50f);
                selfie.setVisibility(View.VISIBLE);
                count.setText("1");
            }
        });
        hide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selfie.getVisibility() == View.VISIBLE)
                {
                    selfie.setVisibility(View.INVISIBLE);
                    hide.setText("SHOW");
                }else{
                    selfie.setVisibility(View.VISIBLE);
                    ourCount++;
                    count.setText("" + 1);
                    hide.setText("HIDE");
                }
            }
        });
        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvText.setGravity(Gravity.LEFT);
            }
        });
        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvText.setGravity(Gravity.RIGHT);
            }
        });
        center.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvText.setGravity(Gravity.CENTER);
            }
        });
        small.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selfie.getLayoutParams().height = 100;
                selfie.requestLayout();
            }
        });
        medium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selfie.getLayoutParams().height = 200;
                selfie.requestLayout();
            }
        });
        large.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selfie.getLayoutParams().height = 400;
                selfie.requestLayout();
            }
        });
        dim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selfie.setAlpha(.33f);
                selfie.requestLayout();
            }
            });
        bright.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               selfie.setAlpha(1.0f);
               selfie.requestLayout();
           }
        });
    }
}
